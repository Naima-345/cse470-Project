import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.jsx'
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import Signup from './signup';
import Login from './test';
import './home';
import './employee'
import './App'
import './home'


const router = createBrowserRouter([
  {
    path: "/login",
    element: <Login/>,
  },

  {
    path: "/signup",
    element: <Signup/>,
  }
]);


ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
