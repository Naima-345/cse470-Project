import React from "react";

function Home(){
    return(
        <center>
            <h1>
                This is Home Component
            </h1>
        </center>
    )
}

export default Home;
