import Footer from "./components/footer/footer";
import Home from "./components/home/home";
import Navbar from "./components/navbar/navbar";


const App = () => {
  return (
    <>
    <Navbar/>
    <Home/>
    <Footer/>
    </>
  );
};

export default App;