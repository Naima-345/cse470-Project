const express = require("express")
const mongoose = require("mongoose")
const cors = require("cors")

const app = express()

const EmployeeModel = require('./src/model/Employee')

app.use(cors())
app.use(express.json())


mongoose
    .connect(process.env.DB_URI, { dbName: "demo_db" }).then(() => {

        console.log("connected to DB successfully");
        // Listening to requests if DB connection is successful
        app.listen(4000, "localhost", () => console.log("Listening to port 4000"));
    })
    .catch((err) => console.log(err));

app.post('/signup', (req, res) => {
    EmployeeModel.create(req.body)
        .then(employees => res.json(employees))
        .catch(err => res.json(err));
});




app.listen(3001, () => {
    console.log("Server is running")
})