const mongoose = require('mongoose');

mongoose.connect(process.env.DB_URI, { dbname: "demo_db" })
    .then(() => {
        console.log('mongodb connected');
    })
    .catch(() => {
        console.log('failed to connect');
    });

const loginSignUpTutorial = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    }
})

const collection = new mongoose.model("Collection1", LogInSchema)

module.export = collection